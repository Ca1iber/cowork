#include <tl_templates/maca/gemm.h>
#include <tl_templates/maca/copy.h>
#include <tl_templates/maca/reduce.h>
#include <tl_templates/maca/intrin.h>
#include <tl_templates/maca/atomic.h>
#include <tl_templates/maca/threadblock_swizzle.h>
#include <tl_templates/maca/debug.h>

extern "C" __global__ void native_sparse_attention_kernel(const int* __restrict__ BlockIndices, const half_t* __restrict__ K, half_t* __restrict__ Output, const half_t* __restrict__ Q, const half_t* __restrict__ V);
extern "C" __global__ void __launch_bounds__(64, 1) native_sparse_attention_kernel(const int* __restrict__ BlockIndices, const half_t* __restrict__ K, half_t* __restrict__ Output, const half_t* __restrict__ Q, const half_t* __restrict__ V) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  half_t q_shared[32];
  float output_acc[32];
  float denominator[1];
  float block_max[1];
  float scores[8];
  half_t k_local[64];
  float previous_max[1];
  float rescale[1];
  float block_sum[1];
  half_t scores_half[8];
  half_t output_shared_local_cast[4];
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    *(uint4*)(q_shared + (i * 8)) = *(uint4*)(Q + (((((((int)blockIdx.z) * 2097152) + (((int)blockIdx.x) * 2048)) + ((((int)threadIdx.x) & 15) * 128)) + (i * 32)) + ((((int)threadIdx.x) >> 4) * 8)));
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 8; ++i_1) {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(output_acc + (i_1 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  denominator[0] = 0x0p+0f/*0.000000e+00*/;
  block_max[0] = -MACART_INF_F;
  int block_start = (BlockIndices[((((int)blockIdx.z) * 1024) + ((int)blockIdx.x))] * 32);
  if ((0 <= block_start) && (block_start <= ((int)blockIdx.x))) {
    #pragma unroll
    for (int i_2 = 0; i_2 < 2; ++i_2) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(scores + (i_2 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
    for (int local_ki = 0; local_ki < 4; ++local_ki) {
      for (int j = 0; j < 2; ++j) {
        half_t broadcast_var_2 = half_t(0x0p+0f/*0.000000e+00*/);
        uint4 condval;
        if (((((block_start + (((int)threadIdx.x) & 15)) >> 4) + j) < 64)) {
          condval = *(uint4*)(K + ((((((((int64_t)((int)blockIdx.z)) * (int64_t)131072) + (((int64_t)j) * (int64_t)2048)) + (((int64_t)block_start) * (int64_t)128)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)15) * (int64_t)128)) + (((int64_t)local_ki) * (int64_t)32)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)4) * (int64_t)8)));
        } else {
          condval = make_uint4(__pack_half2(broadcast_var_2, broadcast_var_2), __pack_half2(broadcast_var_2, broadcast_var_2), __pack_half2(broadcast_var_2, broadcast_var_2), __pack_half2(broadcast_var_2, broadcast_var_2));
        }
        *(uint4*)(k_local + ((local_ki * 16) + (j * 8))) = condval;
      }
    }
    for (int ki = 0; ki < 4; ++ki) {
      for (int kp = 0; kp < 2; ++kp) {
        for (int j_1 = 0; j_1 < 2; ++j_1) {
          {
      *(((float32x4*)scores) + j_1) = __builtin_mxc_mma_16x16x16f16(*(((float16x4*)k_local) + (((ki * 4) + (j_1 * 2)) + kp)),
                    *(((float16x4*)q_shared) + ((ki * 2) + kp)),
                    *(((float32x4*)scores) + j_1));
    };
        }
      }
    }
    #pragma unroll
    for (int i_3 = 0; i_3 < 8; ++i_3) {
      float condval_1;
      if (((((((i_3 >> 2) * 16) + ((((int)threadIdx.x) >> 4) * 4)) + block_start) + (i_3 & 3)) <= ((int)blockIdx.x))) {
        condval_1 = scores[i_3];
      } else {
        condval_1 = -MACART_INF_F;
      }
      scores[i_3] = condval_1;
    }
    previous_max[0] = block_max[0];
    block_max[0] = -MACART_INF_F;
    block_max[0] = -MACART_INF_F;
    #pragma unroll
    for (int rv = 0; rv < 8; ++rv) {
      block_max[0] = max(block_max[0], scores[(((rv & 1) * 4) + (rv >> 1))]);
    }
    block_max[0] = tl::AllReduce<tl::MaxOp, 64, 16, 0>::run(block_max[0], (&(((float*)buf_dyn_shmem)[0])));
    rescale[0] = exp2f(((previous_max[0] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/) - (block_max[0] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/)));
    #pragma unroll
    for (int i_4 = 0; i_4 < 8; ++i_4) {
      scores[i_4] = exp2f(((scores[i_4] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/) - (block_max[0] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/)));
    }
  }
  __syncthreads();
  if ((0 <= block_start) && (block_start <= ((int)blockIdx.x))) {
    block_sum[0] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int rv_1 = 0; rv_1 < 8; ++rv_1) {
      block_sum[0] = (block_sum[0] + scores[(((rv_1 & 1) * 4) + (rv_1 >> 1))]);
    }
    block_sum[0] = tl::AllReduce<tl::SumOp, 64, 16, 0>::run(block_sum[0], (&(((float*)buf_dyn_shmem)[0])));
    denominator[0] = ((denominator[0] * rescale[0]) + block_sum[0]);
    #pragma unroll
    for (int i_5 = 0; i_5 < 2; ++i_5) {
      uint2 __1;
      float4 v_ = *(float4*)(scores + (i_5 * 4));
      ((half2*)(&__1))[0] = __float22half2_rn(((float2*)(&v_))[0]);
      ((half2*)(&__1))[1] = __float22half2_rn(((float2*)(&v_))[1]);
      *(uint2*)(scores_half + (i_5 * 4)) = __1;
    }
    #pragma unroll
    for (int i_6 = 0; i_6 < 32; ++i_6) {
      output_acc[i_6] = (output_acc[i_6] * rescale[0]);
    }
  }
  __syncthreads();
  if ((0 <= block_start) && (block_start <= ((int)blockIdx.x))) {
    #pragma unroll
    for (int i_7 = 0; i_7 < 8; ++i_7) {
      half_t broadcast_var_3 = half_t(0x0p+0f/*0.000000e+00*/);
      uint4 condval_2;
      if ((((((((int)threadIdx.x) >> 4) + block_start) >> 2) + i_7) < 256)) {
        condval_2 = *(uint4*)(V + ((((((int64_t)((int)blockIdx.z)) * (int64_t)131072) + (((int64_t)i_7) * (int64_t)512)) + (((int64_t)block_start) * (int64_t)128)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
      } else {
        condval_2 = make_uint4(__pack_half2(broadcast_var_3, broadcast_var_3), __pack_half2(broadcast_var_3, broadcast_var_3), __pack_half2(broadcast_var_3, broadcast_var_3), __pack_half2(broadcast_var_3, broadcast_var_3));
      }
      *(uint4*)(((half_t*)buf_dyn_shmem) + (((((((((((int)threadIdx.x) & 15) >> 3) * 2048) + (i_7 * 256)) + ((((int)threadIdx.x) >> 4) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (i_7 & 1)) & 1) * 32)) + ((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 128)) = condval_2;
    }
  }
  __syncthreads();
  if ((0 <= block_start) && (block_start <= ((int)blockIdx.x))) {
    half_t B_local[32];
    for (int ki_1 = 0; ki_1 < 2; ++ki_1) {
      for (int j_2 = 0; j_2 < 8; ++j_2) {
        for (int local_id = 0; local_id < 4; ++local_id) {
          B_local[((j_2 * 4) + local_id)] = ((half_t*)buf_dyn_shmem)[((((((((((j_2 >> 2) * 2048) + (ki_1 * 1024)) + ((((int)threadIdx.x) >> 4) * 256)) + (local_id * 64)) + (((((((int)threadIdx.x) & 31) >> 4) + ((j_2 & 3) >> 1)) & 1) * 32)) + ((((local_id >> 1) + (j_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (local_id & 1)) & 1) * 8)) + (((int)threadIdx.x) & 7)) + 128)];
        }
      }
      for (int j_3 = 0; j_3 < 8; ++j_3) {
        {
      *(((float32x4*)output_acc) + j_3) = __builtin_mxc_mma_16x16x16f16(*(((float16x4*)B_local) + j_3),
                    *(((float16x4*)scores_half) + ki_1),
                    *(((float32x4*)output_acc) + j_3));
    };
      }
    }
  }
  #pragma unroll
  for (int i_8 = 0; i_8 < 32; ++i_8) {
    output_acc[i_8] = (output_acc[i_8] / denominator[0]);
  }
  __syncthreads();
  #pragma unroll
  for (int i_9 = 0; i_9 < 8; ++i_9) {
    uint2 __2;
    float4 v__1 = *(float4*)(output_acc + (i_9 * 4));
    ((half2*)(&__2))[0] = __float22half2_rn(((float2*)(&v__1))[0]);
    ((half2*)(&__2))[1] = __float22half2_rn(((float2*)(&v__1))[1]);
    *(uint2*)(output_shared_local_cast + 0) = __2;
    *(uint2*)(((half_t*)buf_dyn_shmem) + (((((((i_9 >> 2) * 1024) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_9 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_9 & 1)) & 1) * 16)) + ((((((int)threadIdx.x) >> 5) + (((int)threadIdx.x) & 1)) & 1) * 8)) + (((((int)threadIdx.x) & 31) >> 4) * 4))) = *(uint2*)(output_shared_local_cast + 0);
  }
  __syncthreads();
  #pragma unroll
  for (int i_10 = 0; i_10 < 4; ++i_10) {
    *(uint4*)(Output + ((((((int)blockIdx.z) * 2097152) + (((int)blockIdx.x) * 2048)) + (i_10 * 512)) + (((int)threadIdx.x) * 8))) = *(uint4*)(((half_t*)buf_dyn_shmem) + ((((((((((int)threadIdx.x) & 15) >> 3) * 1024) + (i_10 * 256)) + ((((int)threadIdx.x) >> 4) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (i_10 & 1)) & 1) * 32)) + ((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)));
  }
}

